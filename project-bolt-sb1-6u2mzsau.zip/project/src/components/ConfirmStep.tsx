import { CheckCircle, XCircle } from 'lucide-react';

interface ConfirmStepProps {
  model: string;
  onConfirm: () => void;
  onRetry: () => void;
}

export const ConfirmStep = ({ model, onConfirm, onRetry }: ConfirmStepProps) => {
  return (
    <div className="animate-fade-in">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold mb-2 text-white">Model Detected</h2>
        <p className="text-slate-400">Please confirm the extracted model number</p>
      </div>

      <div className="glass-card p-8 mb-6 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500/20 rounded-full mb-4">
          <CheckCircle className="text-green-400" size={32} />
        </div>
        <div className="text-3xl font-bold text-white mb-2 tracking-wide">
          {model}
        </div>
        <p className="text-slate-400 text-sm">Extracted model number</p>
      </div>

      <div className="space-y-3">
        <button
          onClick={onConfirm}
          className="w-full btn-gradient py-4 flex items-center justify-center gap-2"
        >
          <CheckCircle size={20} />
          <span className="font-medium">Confirm & Continue</span>
        </button>

        <button
          onClick={onRetry}
          className="w-full btn-secondary py-4 flex items-center justify-center gap-2"
        >
          <XCircle size={20} />
          <span className="font-medium">Scan Again</span>
        </button>
      </div>
    </div>
  );
};
