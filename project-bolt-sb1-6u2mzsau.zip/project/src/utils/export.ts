import { ProductEntry } from '../types';

export const copyToClipboard = (entries: ProductEntry[]): void => {
  const text = entries
    .map((entry) => `${entry.model} - ${entry.quantity} ${entry.unit}`)
    .join('\n');

  navigator.clipboard.writeText(text);
};

export const downloadCSV = (entries: ProductEntry[]): void => {
  const csv = [
    'MODEL,PCS,METER',
    ...entries.map((entry) => {
      const pcs = entry.unit === 'pcs' ? entry.quantity : '';
      const meter = entry.unit === 'meter' ? entry.quantity : '';
      return `${entry.model},${pcs},${meter}`;
    })
  ].join('\n');

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `product-list-${Date.now()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
