export interface ProductEntry {
  id: string;
  model: string;
  quantity: number;
  unit: 'pcs' | 'meter';
  timestamp: number;
}

export type AppStep = 'scan' | 'confirm' | 'quantity' | 'list' | 'manual';
