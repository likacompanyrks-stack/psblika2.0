import { useState, useEffect } from 'react';
import { Package } from 'lucide-react';
import { ScanStep } from './components/ScanStep';
import { ConfirmStep } from './components/ConfirmStep';
import { QuantityStep } from './components/QuantityStep';
import { ProductList } from './components/ProductList';
import { ManualEntryStep } from './components/ManualEntryStep';
import { processImage } from './utils/ocr';
import { extractModelNumber } from './utils/modelExtractor';
import { loadEntries, saveEntries } from './utils/storage';
import { copyToClipboard, downloadCSV } from './utils/export';
import { AppStep, ProductEntry } from './types';

function App() {
  const [step, setStep] = useState<AppStep>('scan');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [detectedModel, setDetectedModel] = useState<string | null>(null);
  const [entries, setEntries] = useState<ProductEntry[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setEntries(loadEntries());

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js');
    }
  }, []);

  useEffect(() => {
    saveEntries(entries);
  }, [entries]);

  const handleScan = async (file: File) => {
    setIsProcessing(true);
    setProgress(0);
    setError(null);

    try {
      const text = await processImage(file, setProgress);
      const model = extractModelNumber(text);

      if (model) {
        setDetectedModel(model);
        setStep('confirm');
      } else {
        setError('No model number detected. Please try again with a clearer image.');
      }
    } catch (err) {
      setError('Failed to process image. Please try again.');
      console.error(err);
    } finally {
      setIsProcessing(false);
      setProgress(0);
    }
  };

  const handleConfirm = () => {
    setStep('quantity');
  };

  const handleRetry = () => {
    setDetectedModel(null);
    setStep('scan');
    setError(null);
  };

  const handleQuantitySubmit = (quantity: number, unit: 'pcs' | 'meter') => {
    if (detectedModel) {
      const newEntry: ProductEntry = {
        id: Date.now().toString(),
        model: detectedModel,
        quantity,
        unit,
        timestamp: Date.now(),
      };

      setEntries([...entries, newEntry]);
      setStep('list');
    }
  };

  const handleAddAnother = () => {
    setDetectedModel(null);
    setStep('scan');
    setError(null);
  };

  const handleEdit = (id: string, quantity: number) => {
    setEntries(entries.map((e) => (e.id === id ? { ...e, quantity } : e)));
  };

  const handleDelete = (id: string) => {
    setEntries(entries.filter((e) => e.id !== id));
  };

  const handleCopy = () => {
    copyToClipboard(entries);
  };

  const handleDownload = () => {
    downloadCSV(entries);
  };

  const handleBackFromQuantity = () => {
    setStep('confirm');
  };

  const handleManualEntry = () => {
    setStep('manual');
  };

  const handleManualSubmit = (model: string, quantity: number, unit: 'pcs' | 'meter') => {
    const newEntry: ProductEntry = {
      id: Date.now().toString(),
      model,
      quantity,
      unit,
      timestamp: Date.now(),
    };

    setEntries([...entries, newEntry]);
    setStep('list');
  };

  const handleBackFromManual = () => {
    if (entries.length > 0) {
      setStep('list');
    } else {
      setStep('scan');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="safe-area-container">
        <header className="py-6 px-4 border-b border-slate-700/50 backdrop-blur-sm bg-slate-900/50 sticky top-0 z-10">
          <div className="max-w-2xl mx-auto flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center">
              <Package size={24} className="text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-bold text-white">Product Scanner</h1>
              <p className="text-xs text-slate-400 mt-0.5">Made with ❤️ by LIKA</p>
            </div>
          </div>
        </header>

        <main className="max-w-2xl mx-auto px-4 py-8">
          {error && (
            <div className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-xl text-red-200 animate-fade-in">
              {error}
            </div>
          )}

          {step === 'scan' && (
            <ScanStep
              onScan={handleScan}
              isProcessing={isProcessing}
              progress={progress}
              onManualEntry={handleManualEntry}
            />
          )}

          {step === 'confirm' && detectedModel && (
            <ConfirmStep model={detectedModel} onConfirm={handleConfirm} onRetry={handleRetry} />
          )}

          {step === 'quantity' && detectedModel && (
            <QuantityStep
              model={detectedModel}
              onSubmit={handleQuantitySubmit}
              onBack={handleBackFromQuantity}
            />
          )}

          {step === 'manual' && (
            <ManualEntryStep onSubmit={handleManualSubmit} onBack={handleBackFromManual} />
          )}

          {step === 'list' && (
            <ProductList
              entries={entries}
              onAddAnother={handleAddAnother}
              onManualEntry={handleManualEntry}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onCopy={handleCopy}
              onDownload={handleDownload}
            />
          )}
        </main>

        <footer className="max-w-2xl mx-auto px-4 pb-8 pt-4">
          <div className="text-center text-xs text-slate-500">
            <p>More updates coming soon!</p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
