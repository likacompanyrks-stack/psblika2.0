import { Plus, ArrowLeft } from 'lucide-react';
import { useState } from 'react';

interface QuantityStepProps {
  model: string;
  onSubmit: (quantity: number, unit: 'pcs' | 'meter') => void;
  onBack: () => void;
}

const QUICK_QUANTITIES = [8, 10, 18, 20, 30];

export const QuantityStep = ({ model, onSubmit, onBack }: QuantityStepProps) => {
  const [quantity, setQuantity] = useState<string>('');
  const [selectedQuick, setSelectedQuick] = useState<number | null>(null);
  const [unit, setUnit] = useState<'pcs' | 'meter'>('pcs');

  const handleQuickSelect = (qty: number) => {
    setSelectedQuick(qty);
    setQuantity('');
  };

  const handleSubmit = () => {
    const finalQty = selectedQuick || parseInt(quantity);
    if (finalQty > 0) {
      onSubmit(finalQty, unit);
    }
  };

  const isValid = selectedQuick !== null || (quantity !== '' && parseInt(quantity) > 0);

  return (
    <div className="animate-fade-in">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-6"
      >
        <ArrowLeft size={20} />
        <span>Back</span>
      </button>

      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold mb-2 text-white">Enter Quantity</h2>
        <p className="text-slate-400">How many pieces of this product?</p>
      </div>

      <div className="glass-card p-6 mb-6">
        <div className="text-center mb-4">
          <div className="text-xl font-bold text-cyan-400 mb-1">{model}</div>
          <div className="text-sm text-slate-400">Model number</div>
        </div>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">Quick Select</label>
          <div className="grid grid-cols-5 gap-2">
            {QUICK_QUANTITIES.map((qty) => (
              <button
                key={qty}
                onClick={() => handleQuickSelect(qty)}
                className={`py-3 rounded-xl font-semibold transition-all ${
                  selectedQuick === qty
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg scale-105'
                    : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {qty}
              </button>
            ))}
          </div>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-700"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-3 bg-slate-900 text-slate-500">or</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">Custom Amount</label>
          <input
            type="number"
            min="1"
            value={quantity}
            onChange={(e) => {
              setQuantity(e.target.value);
              setSelectedQuick(null);
            }}
            placeholder="Enter quantity"
            className="w-full px-4 py-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-lg"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-3">Unit</label>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => setUnit('pcs')}
              className={`py-4 rounded-xl font-semibold transition-all ${
                unit === 'pcs'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
              }`}
            >
              PCS
            </button>
            <button
              onClick={() => setUnit('meter')}
              className={`py-4 rounded-xl font-semibold transition-all ${
                unit === 'meter'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg'
                  : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
              }`}
            >
              Meter
            </button>
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!isValid}
          className="w-full btn-gradient py-4 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus size={20} />
          <span className="font-medium">Add Product</span>
        </button>
      </div>
    </div>
  );
};
