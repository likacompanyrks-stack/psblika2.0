import { Copy, Download, Edit2, Trash2, Plus, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import { ProductEntry } from '../types';

interface ProductListProps {
  entries: ProductEntry[];
  onAddAnother: () => void;
  onManualEntry: () => void;
  onEdit: (id: string, quantity: number) => void;
  onDelete: (id: string) => void;
  onCopy: () => void;
  onDownload: () => void;
}

export const ProductList = ({
  entries,
  onAddAnother,
  onManualEntry,
  onEdit,
  onDelete,
  onCopy,
  onDownload,
}: ProductListProps) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [copied, setCopied] = useState(false);

  const handleEdit = (entry: ProductEntry) => {
    setEditingId(entry.id);
    setEditValue(entry.quantity.toString());
  };

  const handleSaveEdit = (id: string) => {
    const qty = parseInt(editValue);
    if (qty > 0) {
      onEdit(id, qty);
      setEditingId(null);
    }
  };

  const handleCopy = () => {
    onCopy();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="animate-fade-in">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold mb-2 text-white">Product List</h2>
        <p className="text-slate-400">{entries.length} item{entries.length !== 1 ? 's' : ''} added</p>
      </div>

      <div className="space-y-3 mb-6">
        {entries.map((entry, index) => (
          <div
            key={entry.id}
            className="glass-card p-4 animate-slide-up"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-white truncate">{entry.model}</div>
                {editingId === entry.id ? (
                  <div className="flex items-center gap-2 mt-2">
                    <input
                      type="number"
                      min="1"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      className="w-24 px-3 py-1 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                      autoFocus
                    />
                    <button
                      onClick={() => handleSaveEdit(entry.id)}
                      className="px-3 py-1 bg-cyan-600 text-white rounded-lg text-sm font-medium hover:bg-cyan-700 transition-colors"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="px-3 py-1 bg-slate-700 text-white rounded-lg text-sm font-medium hover:bg-slate-600 transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div className="text-sm text-slate-400 mt-1">{entry.quantity} {entry.unit}</div>
                )}
              </div>

              {editingId !== entry.id && (
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(entry)}
                    className="p-2 bg-slate-700/50 hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    <Edit2 size={16} className="text-slate-300" />
                  </button>
                  <button
                    onClick={() => onDelete(entry.id)}
                    className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg transition-colors"
                  >
                    <Trash2 size={16} className="text-red-400" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-3 mb-6">
        <button
          onClick={onAddAnother}
          className="w-full btn-gradient py-4 flex items-center justify-center gap-2"
        >
          <Plus size={20} />
          <span className="font-medium">Scan Another Product</span>
        </button>

        <button
          onClick={onManualEntry}
          className="w-full btn-secondary py-3 flex items-center justify-center gap-2"
        >
          <span className="font-medium">Or Type Manually</span>
        </button>

        <div className="grid grid-cols-2 gap-3 pt-3">
          <button
            onClick={handleCopy}
            disabled={entries.length === 0}
            className="btn-secondary py-4 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {copied ? (
              <>
                <CheckCircle size={18} className="text-green-400" />
                <span className="font-medium">Copied!</span>
              </>
            ) : (
              <>
                <Copy size={18} />
                <span className="font-medium">Copy</span>
              </>
            )}
          </button>

          <button
            onClick={onDownload}
            disabled={entries.length === 0}
            className="btn-secondary py-4 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download size={18} />
            <span className="font-medium">CSV</span>
          </button>
        </div>
      </div>
    </div>
  );
};
